document.addEventListener("DOMContentLoaded", function() {
    // Load colors from API
    fetch('/api/colors')
        .then(response => response.json())
        .then(data => {
            const player1ColorSelect = document.getElementById('player1Color');
            const player2ColorSelect = document.getElementById('player2Color');
            data.forEach(color => {
                const option1 = document.createElement('option');
                const option2 = document.createElement('option');
                option1.value = option2.value = color.ID;  // Assuming 'ID' is the identifier
                option1.text = option2.text = color.Color;  // Assuming 'Color' is the color name
                player1ColorSelect.appendChild(option1);
                player2ColorSelect.appendChild(option2);
            });
        });

    // Start game logic
    document.getElementById('startGame').addEventListener('click', function() {
        const player1Color = document.getElementById('player1Color').value;
        const player2Color = document.getElementById('player2Color').value;
        if (player1Color && player2Color) {
            startGame(player1Color, player2Color);
        } else {
            alert("Please select colors for both players!");
        }
    });
});

let currentPlayer = 1;
let playerColors = {1: null, 2: null};
let startTime;

function startGame(player1Color, player2Color) {
    playerColors[1] = player1Color;
    playerColors[2] = player2Color;
    document.getElementById('whosturn').textContent = "Spieler 1's Zug";
    // Initialize board
    const board = document.getElementById('board');
    board.innerHTML = '';
    for (let i = 0; i < 42; i++) {
        const cell = document.createElement('ul');
        const cellContent = document.createElement('p');
        cell.appendChild(cellContent);
        cell.addEventListener('click', () => makeMove(i));
        board.appendChild(cell);
    }
    startTime = new Date();
}

function makeMove(index) {
    const cells = document.querySelectorAll('#board ul p');
    if (cells[index].style.backgroundColor === '' || cells[index].style.backgroundColor === 'white') {
        cells[index].style.backgroundColor = playerColors[currentPlayer];
        // Save the move to the database
        fetch('/api/game/move', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({position: index, player_id: currentPlayer})
        }).then(response => response.json())
          .then(data => {
              if (checkWin()) {
                  endGame(currentPlayer);
              } else {
                  currentPlayer = currentPlayer === 1 ? 2 : 1;
                  document.getElementById('whosturn').textContent = `Spieler ${currentPlayer}'s Zug`;
              }
          });
    }
}

function checkWin() {
    const cells = document.querySelectorAll('#board ul p');
    const patterns = [
        // Horizontal patterns
        [0, 1, 2, 3], [1, 2, 3, 4], [2, 3, 4, 5], [3, 4, 5, 6],
        [7, 8, 9, 10], [8, 9, 10, 11], [9, 10, 11, 12], [10, 11, 12, 13],
        [14, 15, 16, 17], [15, 16, 17, 18], [16, 17, 18, 19], [17, 18, 19, 20],
        [21, 22, 23, 24], [22, 23, 24, 25], [23, 24, 25, 26], [24, 25, 26, 27],
        [28, 29, 30, 31], [29, 30, 31, 32], [30, 31, 32, 33], [31, 32, 33, 34],
        [35, 36, 37, 38], [36, 37, 38, 39], [37, 38, 39, 40], [38, 39, 40, 41],
        // Vertical patterns
        [0, 7, 14, 21], [7, 14, 21, 28], [14, 21, 28, 35],
        [1, 8, 15, 22], [8, 15, 22, 29], [15, 22, 29, 36],
        [2, 9, 16, 23], [9, 16, 23, 30], [16, 23, 30, 37],
        [3, 10, 17, 24], [10, 17, 24, 31], [17, 24, 31, 38],
        [4, 11, 18, 25], [11, 18, 25, 32], [18, 25, 32, 39],
        [5, 12, 19, 26], [12, 19, 26, 33], [19, 26, 33, 40],
        [6, 13, 20, 27], [13, 20, 27, 34], [20, 27, 34, 41],
        // Diagonal patterns
        [3, 9, 15, 21], [4, 10, 16, 22], [5, 11, 17, 23], [6, 12, 18, 24],
        [10, 16, 22, 28], [11, 17, 23, 29], [12, 18, 24, 30], [13, 19, 25, 31],
        [17, 23, 29, 35], [18, 24, 30, 36], [19, 25, 31, 37], [20, 26, 32, 38],
        [2, 10, 18, 26], [1, 9, 17, 25], [0, 8, 16, 24],
        [9, 17, 25, 33], [8, 16, 24, 32], [7, 15, 23, 31],
        [16, 24, 32, 40], [15, 23, 31, 39], [14, 22, 30, 38],
        [21, 15, 9, 3], [22, 16, 10, 4], [23, 17, 11, 5], [24, 18, 12, 6],
        [28, 22, 16, 10], [29, 23, 17, 11], [30, 24, 18, 12], [31, 25, 19, 13],
        [35, 29, 23, 17], [36, 30, 24, 18], [37, 31, 25, 19], [38, 32, 26, 20]
    ];
    for (let pattern of patterns) {
        if (pattern.every(index => cells[index].style.backgroundColor === playerColors[currentPlayer])) {
            return true;
        }
    }
    return false;
}

function endGame(winner) {
    const playtime = calculatePlaytime();
    fetch('/api/game/end', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({winner_id: winner, playtime: playtime})
    }).then(response => response.json())
      .then(data => alert(`Spiel beendet! Gewinner: Spieler ${winner}`));
}

function calculatePlaytime() {
    const endTime = new Date();
    const duration = new Date(endTime - startTime);
    return `${duration.getUTCHours()}:${duration.getUTCMinutes()}:${duration.getUTCSeconds()}`;
}
