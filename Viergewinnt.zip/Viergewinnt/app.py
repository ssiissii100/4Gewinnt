from flask import Flask, render_template, jsonify, request
import mysql.connector
from datetime import datetime

app = Flask(__name__)

# Database connection
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='viergewinnt'
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game')
def game():
    return render_template('game.html')

@app.route('/statistic')
def statistic():
    return render_template('statistic.html')

@app.route('/api/colors', methods=['GET'])
def get_colors():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM colors")
    colors = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(colors)

@app.route('/api/players', methods=['POST'])
def set_player_colors():
    data = request.get_json()
    player1_color = data.get('player1_color')
    player2_color = data.get('player2_color')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE players SET ColorFK = %s WHERE ID = 1", (player1_color,))
    cursor.execute("UPDATE players SET ColorFK = %s WHERE ID = 2", (player2_color,))
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({'status': 'Player colors updated'})

@app.route('/api/game/start', methods=['POST'])
def start_game():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM activgame")
    cursor.execute("INSERT INTO activgame (PlayerFK) VALUES (1), (2)")
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({'status': 'Game started'})

@app.route('/api/game/move', methods=['POST'])
def make_move():
    data = request.get_json()
    position = data.get('position')
    player_id = data.get('player_id')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE activgame SET PlayerFK = %s WHERE ID = %s", (player_id, position))
    conn.commit()
    cursor.close()
    conn.close()

    # Check win condition here (you need to implement this logic)
    # win = check_win_condition()

    return jsonify({'status': 'Move made'})

@app.route('/api/game/end', methods=['POST'])
def end_game():
    data = request.get_json()
    winner_id = data.get('winner_id')
    playtime = data.get('playtime')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO statistic (PlayerFK, Playtime) VALUES (%s, %s)", (winner_id, playtime))
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({'status': 'Game ended'})

@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT s.ID, p.ColorFK as Winner, s.Playtime FROM statistic s LEFT JOIN players p ON s.PlayerFK = p.ID")
    statistics = cursor.fetchall()
    cursor.close()
    conn.close()
    
    result = []
    for stat in statistics:
        playtime = str(stat['Playtime'])
        winner = 'P1' if stat['Winner'] == 1 else 'P2'
        result.append({'ID': stat['ID'], 'Winner': winner, 'Playtime': playtime})
    
    return jsonify(result)

@app.route('/api/statistics', methods=['POST'])
def reset_statistics():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM statistic")
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'status': 'Statistics reset'})

if __name__ == '__main__':
    app.run(debug=True)
